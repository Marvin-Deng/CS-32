#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

void Player::doSomething() {

	// WAITING STATE

	if (waiting)
	{
		int action = getWorld()->getAction(pNum);
		if (action == ACTION_ROLL) {
			int die_roll = randInt(1, 10);
			ticks_to_move = die_roll * 8;
			waiting = false;
		}
		else if (action == ACTION_FIRE) {

		}
		else {
			return;
		}
	}

	// WALKING STATE 

	if (!waiting) {

		int directions[4] = { up, down, right, left };

		// If new position isn't valid, change walking direction
		if (!isValidPos()) {
			std::cout << "Current: " << getX() / 16 << " " << getY() / 16 << "    ";
			if (currDir == right || currDir == left) {
				currDir = up;
				if (!isValidPos()) {
					currDir = down;
				}
			}
			else {
				currDir = right;
				if (!isValidPos()) {
					currDir = left;
				}
			}

			// Change sprite direction
			if (currDir == left) {
				setDirection(180);
			} else {
				setDirection(0);
			}
		}
		moveAtAngle(currDir, 2); // Move 2 pixels in the current direction
		ticks_to_move--;
		if (ticks_to_move == 0) {
			waiting = true;
		}
	}
}

bool Player::isValidPos() {
	int newX, newY;
	getPositionInThisDirection(currDir, 16, newX, newY);

	Board::GridEntry ge = getWorld()->getBoard().getContentsOf(newX / 16, newY / 16);

	switch (ge) {

	case Board::empty:
		return false;
	default:
		return true;
	}
}

void CoinSquare::doSomething() {
	if (!alive) {
		return;
	}
}

