#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

void Player::doSomething() {

	//// WAITING STATE ////

	if (waiting)
	{
		int action = getWorld()->getAction(pNum);
		if (action == ACTION_ROLL) {
			int die_roll = randInt(1, 10);
			ticks_to_move = die_roll * 8;
			waiting = false;
		}
		else if (action == ACTION_FIRE) {

		}
		else {
			return;
		}
	}

	//// WALKING STATE ////

	if (!waiting) {

		// Determine next position based on current walking direction
		int newX, newY;
		getPositionInThisDirection(currDir, 16, newX, newY);

		int directions[4] = { up, down, right, left };

		// If new position isn't valid, change walking direction
		if (!getWorld()->isValidPos(newX, newY)) {
			for (int dir : directions) { // Loop through direction array to determine next valid walking direction
				if (abs(currDir - dir) != 90) { // New direction must be perpendicular ot old one
					continue;
				}
				getPositionInThisDirection(dir, 16, newX, newY);
				if (getWorld()->isValidPos(newX, newY)) {
					currDir = dir; // If a new walking direction is valid, update the current walking direction
					break;
				}
			}
			// Change sprite direction
			if (currDir == left) {
				setDirection(180);
			} else {
				setDirection(0);
			}
		}
		moveAtAngle(currDir, 2); // Move 2 pixels in the current direction
		ticks_to_move--;
		if (ticks_to_move == 0) {
			waiting = true;
		}
		
	}
	return;
}

void CoinSquare::doSomething() {
	if (!alive) {
		return;
	}
}