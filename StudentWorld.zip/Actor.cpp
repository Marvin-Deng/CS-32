#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

void Player::doSomething() {

	// Waiting state
	if (waiting)
	{
		int action = getWorld()->getAction(pNum);
		if (action == ACTION_ROLL) {
			int die_roll = randInt(1, 10);
			ticks_to_move = die_roll * 8;
			waiting = false;
		}
		else if (action == ACTION_FIRE) {

		}
		else {
			return;
		}
	}

	// Walking state
	if (!waiting) {
		int dir = getDirection();
		int moveX = 0, moveY = 0;
		if (dir == 0) { // move right
			moveX += 16;
		}
		else if (dir == 180) { // move left
			moveX -= 16;
		}
		else if (dir == 90) { // move up
			moveY += 16;
		}
		else if (dir == 270) { // move down
			moveY -= 16;
		}
		int directions[4][2] = { {getX(), getY() + 16}, {getX(), getY() - 16}, {getX() + 16, getY()}, {getX() - 16, getY()} }; // up, down, left, right
	
		if (!getWorld()->isValidPos(getX() + moveX, getY() + moveY)) {
			
		}
		setDirection(90);
		
	}
	return;
}

void CoinSquare::doSomething() {
	if (!alive) {
		return;
	}
}