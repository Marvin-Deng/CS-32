#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <sstream>
using namespace std;

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}


StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    peach = nullptr;
    actors.clear();
}

int StudentWorld::init()
{
    stringstream stream;
    stream << getBoardNumber();
    string num;
    stream >> num;

    Board bd;
    string board_file = assetPath() + "board0" + num + ".txt"; // get the correct board
    Board::LoadResult result = bd.loadBoard(board_file);
    if (result == Board::load_fail_file_not_found)
        cerr << "Could not find board01.txt data file\n";
    else if (result == Board::load_fail_bad_format)
        cerr << "Your board was improperly formatted\n";
    else if (result == Board::load_success) {
        cerr << "Successfully loaded board\n";

        for (int x = 0; x < 16; x++) {
            for (int y = 0; y < 16; y++) {
                Board::GridEntry ge = bd.getContentsOf(x, y);
                int xPos = x * 16;
                int yPos = y * 16;
                switch (ge) {

                case Board::empty:
                    break;

                case Board::player:
                    actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, xPos, yPos));
                    peach = new Peach(this, IID_PEACH, xPos, yPos);
                    break;

                case Board::blue_coin_square:
                    actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, xPos, yPos));
                    break;
                }
            }
        }
    }

	startCountdownTimer(99);  // 99 second timer
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{

    peach->doSomething(); 
    for (Actor* a : actors) {
        a->doSomething();
    }
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    for (Actor* a : actors) {
        delete a; // delete dynmically allocted objects
    }
    actors.clear(); // clears all elements of vector, makes size 0
    delete peach;
    peach = nullptr;
}

StudentWorld::~StudentWorld() { 
    cleanUp();
}

bool StudentWorld::isValidPos(int x, int y) {
    for (Actor* a : actors) {
        if (abs(x - a->getX()) < SPRITE_WIDTH && abs(y - a->getY()) < SPRITE_HEIGHT) {
            return true;
        }
    }        
    return false;
}