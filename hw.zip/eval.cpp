#include "Set.h"  
#include <iostream>
#include <string>
#include <stack>
#include <cctype>
#include <cassert>
using namespace std;

using namespace std;

bool isValid(string infix, const Set& trueValues, const Set& falseValues);

string removeSpaces(string infix);

int checkPrecedence(char c);

string InToPost(string infix);
  
bool PostToEval(string post, const Set& trueValues, const Set& falseValues);

int evaluate(string infix, const Set& trueValues, const Set& falseValues, string& postfix, bool& result) {
    infix = removeSpaces(infix);
	if (!isValid) {
		return 1;
	}
    string post = InToPost(infix);
    postfix = post;
    result = PostToEval(post, trueValues, falseValues);

    return 0;
}

bool isValid(string infix, const Set& trueValues, const Set& falseValues) {
    int len = infix.size();

    // & and | cannot be in the first index
    if (infix[0] == '&' || infix[0] == '|') {
        return false;
    }

    // !, &, |, and ( cannot be in the last index
    int last = infix[len - 1];
    if (last == '!' || last == '&' || last == '|' || last == '(') {
        return false;
    }
      
    int open = 0;
	for (char c : infix) {
        // Checks digits
        if (isdigit(c)) {
            return false;
        }
        // Checks if characters in infix are included in the value sets
		if (isalpha(c) && (!trueValues.contains(c) || !falseValues.contains(c))) {
			return false;
		}
        // Checks if operators are valid
        if (!isalpha(c) && (c != '!' || c != '&' || c != '|' || c != '(' || c != ')')) {
            return false;
        }
        // Checks valid parentheses
        if (c == '(') {
            open++;
        } else if (c == ')') {
            if (open == 0) {
                return false;
            }
            open--;
        }
	}
    return open == 0;
}

string removeSpaces(string infix) {
    string res;
    for (char c : infix) {
        if (c != ' ') {
            res += c;
        }
    }
    return res;
}

int checkPrecedence(char c) {
    if (c == '!') { // highest precedence
        return 3;
    } else if (c == '&') {
        return 2;
    } else if (c == '|') { // lowest precedence
        return 1;
    }
    return 0;
}

string InToPost(string infix) {
    string post = "";
    stack<char> op;
    for (char c : infix) {
        if (isalpha(c)) {
            post += c;
        } 
        else if (c == '(') {
            op.push(c);
        }
        else if (')') {
            // pop stack until matching '('
            while (op.top() != '(') {
                post += op.top();
                op.pop(); // remove the '('
            }
            op.pop();
        }
        else {
            while (!op.empty() && op.top() != '(' && checkPrecedence(c) <= checkPrecedence(op.top())) {
                post += op.top();
                op.pop();
            }
            op.push(c);
        }
    }
    while (!op.empty()) {
        post += op.top();
        op.pop();
    }
    return post;
}

bool PostToEval(string post, const Set& trueValues, const Set& falseValues) {
    stack<bool> op;
    for (char c : post) {
        if (isalpha(c)) { // if letter
            op.push(c);
        }
        else { // if operator
            bool operand2 = trueValues.contains(op.top());;
            op.pop();
            bool operand1 = trueValues.contains(op.top());
            op.pop();
            bool res;
            if (c == '|') {
                if (operand2 || operand1) {
                    op.push(true);
                }
                else {
                    op.push(false);
                }
            }
            else if (c == '&') {
                if (operand2 && operand1) {
                    op.push(true);
                }
                else {
                    op.push(false);
                }
            }
        }
    }
    return op.top();
}


int main()
{
    string trueChars = "tywz";
    string falseChars = "fnx";
    Set trues;
    Set falses;
    for (int k = 0; k < trueChars.size(); k++)
        trues.insert(trueChars[k]);
    for (int k = 0; k < falseChars.size(); k++)
        falses.insert(falseChars[k]);

    string pf;
    bool answer;
    assert(evaluate("w| f", trues, falses, pf, answer) == 0 && pf == "wf|" && answer);
    assert(evaluate("y|", trues, falses, pf, answer) == 1);
    assert(evaluate("n t", trues, falses, pf, answer) == 1);
    assert(evaluate("nt", trues, falses, pf, answer) == 1);
    assert(evaluate("()", trues, falses, pf, answer) == 1);
    assert(evaluate("()z", trues, falses, pf, answer) == 1);
    assert(evaluate("y(n|y)", trues, falses, pf, answer) == 1);
    assert(evaluate("t(&n)", trues, falses, pf, answer) == 1);
    assert(evaluate("(n&(t|y)", trues, falses, pf, answer) == 1);
    assert(evaluate("n+y", trues, falses, pf, answer) == 1);
    assert(evaluate("", trues, falses, pf, answer) == 1);
    assert(evaluate("f  |  !f & (t&n) ", trues, falses, pf, answer) == 0
        && pf == "ff!tn&&|" && !answer);
    assert(evaluate(" x  ", trues, falses, pf, answer) == 0 && pf == "x" && !answer);
    trues.insert('x');
    assert(evaluate("((x))", trues, falses, pf, answer) == 3);
    falses.erase('x');
    assert(evaluate("((x))", trues, falses, pf, answer) == 0 && pf == "x" && answer);
    trues.erase('w');
    assert(evaluate("w| f", trues, falses, pf, answer) == 2);
    falses.insert('w');
    assert(evaluate("w| f", trues, falses, pf, answer) == 0 && pf == "wf|" && !answer);
    cout << "Passed all tests" << endl;
}


