#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <iostream>
#include <sstream>
using namespace std;

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}


StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    peach = nullptr;
    actors.clear();
    bd = new Board;
}

string StudentWorld::intToString(int a) {
    stringstream stream;
    stream << a;
    string num;
    stream >> num;
    return num;
}

Board* StudentWorld::getBoard() {
    return bd;
} 

int StudentWorld::init()
{
    string board_file = assetPath() + "board0" + intToString(getBoardNumber()) + ".txt"; // get the correct board
    Board::LoadResult result = getBoard()->loadBoard(board_file);
    if (result == Board::load_fail_file_not_found)
        cerr << "Could not find board01.txt data file\n";
    else if (result == Board::load_fail_bad_format)
        cerr << "Your board was improperly formatted\n";
    else if (result == Board::load_success) {
        cerr << "Successfully loaded board\n";

        for (int x = 0; x < 16; x++) {
            for (int y = 0; y < 16; y++) {
                Board::GridEntry ge = getBoard()->getContentsOf(x, y);
                int xPos = x * 16;
                int yPos = y * 16;
                switch (ge) {

                case Board::empty:
                    break;

                case Board::player:
                    peach = new Peach(this, IID_PEACH, xPos, yPos);
                    actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, xPos, yPos, 1));
                    break;

                case Board::blue_coin_square:
                    actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, xPos, yPos, 1));
                    break;
                }
            }
        }
    }
	startCountdownTimer(99);  // 99 second timer
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    peach->doSomething(); 
    for (Actor* a : actors) {
        a->doSomething();
    }
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    for (Actor* a : actors) {
        delete a; // delete dynmically allocted objects
    }
    actors.clear(); // clears all elements of vector, makes size 0
    delete peach; 
    peach = nullptr;
    delete bd; // delete the board
}

StudentWorld::~StudentWorld() { 
    cleanUp();
}
