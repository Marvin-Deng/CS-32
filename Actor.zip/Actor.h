#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <string>
 
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(StudentWorld* world, int imageID, int startX, int startY, int depth)
		: GraphObject(imageID, startX, startY, depth), m_world(world)
	{}

	virtual void doSomething() = 0;

	StudentWorld* getWorld() {
		return m_world;
	}

private:
	StudentWorld* m_world;
};

class Player : public Actor
{
public:
	Player(StudentWorld* world, int imageID, int startX, int startY, int playerNum, int depth = 0)
		: Actor(world, imageID, startX, startY, depth), ticks_to_move(0), currDir(right), waiting(true), pNum(playerNum), coins(0)
	{}

	virtual void doSomething();

private:
	bool isValidPos();
	int pNum;
	int ticks_to_move;
	int currDir;
	bool waiting;
	int coins;
};

class Peach : public Player
{
public:
	Peach(StudentWorld* world, int imageID, int startX, int startY, int playerNum = 1)
		: Player(world, imageID, startX, startY, playerNum)
	{}

private:

};

class Square : public Actor
{
public:
	Square(StudentWorld* world, int imageID, int startX, int startY, int depth)
		: Actor(world, imageID, startX, startY, depth)
	{}
private:
	
};

class CoinSquare : public Square
{
public:
	CoinSquare(StudentWorld* world, int imageID, int startX, int startY, int depth)
		: Square(world, imageID, startX, startY, depth), alive(true), coinsGiven(3)
	{}
	virtual void doSomething();

private:
	bool alive;
	int coinsGiven;
};

#endif // ACTOR_H_
