#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

void Player::doSomething() {

	// Waiting state
	if (waiting)
	{
		int action = getWorld()->getAction(getPlayerNum());
		if (action == ACTION_ROLL) {
			int die_roll = randInt(1, 10);
			ticks_to_move = die_roll * 8;
			waiting = false;
		}
		else if (action == ACTION_FIRE) {

		}
		else {
			return;
		}
	}

	// Walking state
	if (!waiting) {

	}
	return;
}