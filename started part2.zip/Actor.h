#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <string>
 
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(StudentWorld* world, int imageID, int startX, int startY, int direction = right, int depth = 0)
		: GraphObject(imageID, startX, startY, direction, depth), m_world(world)
	{}

	virtual void doSomething() = 0;

	StudentWorld* getWorld() const;

private:
	StudentWorld* m_world;
};

class Player : public Actor
{
public:
	Player(StudentWorld* world, int imageID, int startX, int startY, int playerNum)
		: Actor(world, imageID, startX, startY), ticks_to_move(0), currDir(right), waiting(true), pNum(playerNum), coins(0)
	{}

	virtual void doSomething();

private:
	bool isValidPos() const;
	int pNum;
	int ticks_to_move;
	int currDir;
	bool waiting;
	int coins;
};


class Square : public Actor
{
public:
	Square(StudentWorld* world, int imageID, int startX, int startY, int direction = right, int depth = 1)
		: Actor(world, imageID, startX, startY, direction, depth), alive(true)
	{}

	bool isAlive() const;

private:
	bool alive;
};

class CoinSquare : public Square
{
public:
	CoinSquare(StudentWorld* world, int imageID, int startX, int startY, int coins)
		: Square(world, imageID, startX, startY), coinsGiven(coins)
	{}
	virtual void doSomething();

private:
	
	int coinsGiven;
};

class StarSquare : public Square
{
public:
	StarSquare(StudentWorld* world, int imageID, int startX, int startY)
		: Square(world, imageID, startX, startY)
	{}
	virtual void doSomething();

private:
	
};

class DirectionSquare : public Square
{
public:
	DirectionSquare(StudentWorld* world, int imageID, int startX, int startY, int direction)
		: Square(world, imageID, startX, startY, direction)
	{}
	virtual void doSomething();

private:

};

class BankSquare : public Square
{
public:
	BankSquare(StudentWorld* world, int imageID, int startX, int startY)
		: Square(world, imageID, startX, startY)
	{}
	virtual void doSomething();

private:

};

class EventSquare : public Square
{
public:
	EventSquare(StudentWorld* world, int imageID, int startX, int startY)
		: Square(world, imageID, startX, startY)
	{}
	virtual void doSomething();

private:

};

class DroppingSquare : public Square
{
public:
	DroppingSquare(StudentWorld* world, int imageID, int startX, int startY)
		: Square(world, imageID, startX, startY)
	{}
	virtual void doSomething();

private:

};

#endif // ACTOR_H_
